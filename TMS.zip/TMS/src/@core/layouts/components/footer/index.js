// ** Icons Import

const Footer = () => {
  return (
    <div style={{background:'#ffff'}} className="display-hidden">
    </div>
  )
}

export default Footer
