import { lazy } from 'react'

const Access = lazy(() => import('../../views/access'))

const AccessRoutes = [
  {
    path: '/access',
    element: <Access />
  }
]

export default AccessRoutes