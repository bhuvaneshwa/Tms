import { lazy } from 'react'

const Fleets = lazy(() => import('../../views/fleets'))
const FleetDetails = lazy(() => import('../../views/fleets/vehicles/FleetDetails'))
const FleetsRoutes = [
  {
    path: '/master/fleets',
    element: <Fleets />
  },
  {
    path: '/fleets/details/',
    element: <FleetDetails />
  }
]

export default FleetsRoutes
