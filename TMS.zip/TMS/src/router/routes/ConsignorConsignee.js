import { lazy } from 'react'

const ShipperDetailslist = lazy(() => import('../../views/apps/user/view/ConsignorConginee/ShipperDetails'))


const ShipperDetailsRoutes = [
  {
    path: '/shipper-details',
    element: <ShipperDetailslist />
  }
  
]

export default ShipperDetailsRoutes