import { lazy } from 'react'

const Exam = lazy(() => import('../../views/example/Example'))
const ExampleRoutes = [
  {
    path: '/example',
    element: <Exam />
  }
]

export default ExampleRoutes
