import { lazy } from 'react'
import VendorTariff from '../../views/vendors/VendorTariff'
const Company = lazy(() => import('../../views/configure/Company'))
const Users = lazy(() => import('../../views/configure/Users'))
const AccessControl = lazy(() => import('../../views/configure/AccessControl'))
const QuickCode = lazy(() => import('../../views/configure/QuickCode'))
const MasterCustomerlist = lazy(() => import('../../views/customers/Main'))
const CustomerTariff = lazy(() => import('../../views/customers/CustomerTariff'))
const MasterVendorlist = lazy(() => import('../../views/vendors/VendorMain'))
const ShipperDetails = lazy(() => import('../../views/master/shipperdetails'))

const MasterRoutes = [
  {
    path: '/master/company',
    element: <Company />
  },
  {
    path: '/master/users',
    element: <Users />
  },
  {
    path: '/master/access-control',
    element: <AccessControl />
  },
  {
    path: '/master/quick-code',
    element: <QuickCode />
  },
  {
    path: '/master/customer',
    element: <MasterCustomerlist />
  },
  {
    path: '/master/customer/:id',
    element: <CustomerTariff />
  },
  {
    path: '/master/vendor',
    element: <MasterVendorlist />
  },
  {
    path: '/master/vendor/:id',
    element: <VendorTariff />
  },
  {
    path: '/master/shipperdetails',
    element: <ShipperDetails />
  }

]

export default MasterRoutes
