import { lazy } from 'react'

const  Tabscreated = lazy(() => import('../../views/tabslearning/firstmodal'))
//const test = lazy(() => import('../../views/tabslearning/companies'))

const setupRoutes = [
    {
        path: '/master/setup',
        element: <Tabscreated />
      }
    
]

export default setupRoutes