import { lazy } from 'react'

const TripBoard = lazy(() => import('../../views/tripboard/TripBoard'))
const TripDetails = lazy(() => import('../../views/tripboard/TripDetails'))

const Reports = lazy(() => import('../../views/reports/Reports'))
const Invoice = lazy(() => import('../../views/invoice/'))
const FuelTollUpload = lazy(() => import('../../views/fuelandtoll/FuelTollTest'))


const OperationsRoutes = [
  {
    path: '/operations/trip/tripboard',
    element: <TripBoard />
  },
  {
    path: '/operations/trip/details',
    element: <TripDetails />
  },
  {
    path: '/operations/invoice/invoices',
    element: <Invoice />
  },
  {
    path: '/operations/reports/report-test',
    element: <Reports />
  },
  {
    path: '/operations/fuel-toll-upload/fueltolltest',
    element: <FuelTollUpload />
  }
]

export default OperationsRoutes
