// ** Navigation imports
import fleet from './fleet'
import apps from './apps'
import pages from './pages'
import forms from './forms'
import tables from './tables'
import others from './others'
import master from './master'
import operations from './operations'
import charts from './charts'
import dashboards from './dashboards'
import uiElements from './ui-elements'

import example from './example'

// ** Merge & Export
export default [...dashboards, ...master, ...example, ...operations, ...apps, ...fleet, ...pages, ...uiElements, ...forms, ...tables, ...charts, ...others]
