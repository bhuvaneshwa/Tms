// ** Icons Import
import { Archive, Circle, Truck, User, Users, Coffee} from 'react-feather'
// import { BsFilePerson } from 'react-icons/bs'
import { BsFilePerson } from 'react-icons/bs'
import { TbSteeringWheel } from 'react-icons/tb'
import { RiTruckFill } from 'react-icons/ri'

export default [
  {
    header: 'MASTER'
  },
  {
    id: 'setup',
    title: 'Setup',
    icon: <Archive size={20} />,
    badge: 'light-warning',
    navLink:'/master/setup'
    // children: [
    //   {
    //     id: 'company',
    //     title: 'Company',
    //     icon: <Circle size={12} />,
    //     navLink: '/master/company'
    //   },
    //   {
    //     id: 'users',
    //     title: 'Users',
    //     icon: <Circle size={12} />,
    //     navLink: '/master/users'
    //   },
    //   {
    //     id: 'access-control',
    //     title: 'Access Control',
    //     icon: <Circle size={12} />,
    //     navLink: '/apps/roles'
    //   },
    //   {
    //     id: 'quick-code',
    //     title: 'Quick Code',
    //     icon: <Circle size={12} />,
    //     navLink: '/master/quick-code'
    //   }
    // ]
  },
  {
    id: 'fleets',
    title: 'Fleets',
    icon: <Truck size={12} />,
    action: 'read',
    resource: 'ACL',
    navLink:'/master/fleets'
    // children: [
    //   {
    //     id: 'fleets',
    //     title: 'Fleets',
    //     icon: <RiTruckFill size={12} />,
    //     navLink: '/fleets'
    //   },
    //   {
    //     id: 'fleet-pilots',
    //     title: 'Fleet Pilots',
    //     icon: <TbSteeringWheel size={12} />,
    //     navLink: '/fleet/fleet-pilot'
    //   }
    // ]
  },
  {
    id: 'customer',
    title: 'Customer',
    icon: <Users size={12} />,
    action: 'read',
    resource: 'ACL',
    navLink: '/master/customer'
  },
  {
    id: 'vendor',
    title: 'Vendor',
    icon: <BsFilePerson size={12} />,
    action: 'read',
    resource: 'ACL',
    navLink: '/master/vendor'
  }

]
