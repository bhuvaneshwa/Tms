// ** Icons Import
import { Circle } from 'react-feather'

export default [
  {
    id: 'examples',
    title: 'Billing',
    icon: <Circle size={20} />,
    navLink:'/example'
 
   
  }
]
