// ** Icons Import
import { Truck, Circle } from 'react-feather'

export default [
  {
    id: 'fleets',
    title: 'Fleets',
    icon: <Truck size={20} />,
    navLink:'/master/fleets',
    badge: 'light-warning',
    badgeText: '2'
    // children: [
    //   {
    //     id: 'fleets',
    //     title: 'Fleets',
    //     icon: <Circle size={12} />,
    //     navLink: '/fleets'
    //   },
    //   {
    //     id: 'fleetPilots',
    //     title: 'Fleet Pilots',
    //     icon: <Circle size={12} />,
    //     navLink: '/fleet/fleet-pilot'
    //   }

    // ]
  }
]
