import { Truck, User } from "react-feather"

export default [
    {
      header: 'OPERATIONS'
    },
    {
      id: 'trip-board',
      title: 'Trip Board',
      icon: <Truck size={12} />,
      action: 'read',
      resource: 'ACL',
      navLink: '/operations/trip/tripboard'
    },

    {
        id: 'invoice',
        title: 'Invoice',
        icon: <Truck size={12} />,
        action: 'read',
        resource: 'ACL',
        children:[
            {
                id: 'company',
                title: 'Company',
                icon: <User size={12} />,
                navLink: '/operations/invoice/invoices'
              }
              
        ]
      },
      {
        id: 'report',
        title: 'Reports',
        icon: <Truck size={12} />,
        action: 'read',
        resource: 'ACL',
        navLink: '/operations/reports/report-test'
      },
      {
        id: 'fuel-toll-upload',
        title: 'Fuel and Toll Upload',
        icon: <Truck size={12} />,
        action: 'read',
        resource: 'ACL',
        children:[
            {
                id: 'fuel-toll',
                title: 'Fuel Toll Test',
                icon: <User size={12} />,
                navLink: '/operations/fuel-toll-upload/fueltolltest'
              }
        ]
      }
]