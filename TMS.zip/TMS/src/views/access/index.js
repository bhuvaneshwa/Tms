// ** React Imports
import { Fragment } from 'react'

// ** Roles Components
import Table from './Table'
import RoleCards from './RoleCards'

const Access = () => {
  return (
    <Fragment>
      <h3>Roles</h3>
      <RoleCards />
      <h3 className='mt-50'>Total users with their roles</h3>
      <div className='app-user-list'>
        <Table />
      </div>
    </Fragment>
  )
}

export default Access
